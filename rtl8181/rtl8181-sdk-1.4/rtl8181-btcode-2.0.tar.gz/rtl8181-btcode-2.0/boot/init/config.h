#define SDRAM_TEST 	1	
#define ETH_TEST 	0	
#define FLASH_TEST	0	
#define WLAN_TEST	0	
#define NEW_ADDR_SPACE	0	
