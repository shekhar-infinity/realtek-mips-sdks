#include "monitor.h"
#include "etherboot.h"
#include "nic.h"



extern unsigned int	_end;

extern unsigned char 	ethfile[20];
extern struct arptable_t	arptable[MAX_ARP];
#define MAIN_PROMPT						"<RealTek>"
#define printf	prom_printf
#define putchar(x)	serial_outc(x)
#define IPTOUL(a,b,c,d)	((a << 24)| (b << 16) | (c << 8) | d )

int YesOrNo(void);
int CmdHelp( int argc, char* argv[] );
int CmdDumpWord( int argc, char* argv[] );
//int CmdEDl(int argc, char* argv[]);
//int CmdEUl(int argc, char* argv[]);
int CmdCfn(int argc, char* argv[]);

int CmdIp(int argc, char* argv[]);
//int CmdFle(int argc, char* argv[]);
int CmdFlw(int argc, char* argv[]);
int CmdFlr(int argc, char* argv[]);

/*Cyrus Tsai*/
#define TFTP_SERVER 0
#define TFTP_CLIENT 1
extern struct arptable_t  arptable_tftp[3];
/*Cyrus Tsai*/

extern int flasherase(unsigned long src, unsigned int length);
extern int flashwrite(unsigned long dst, unsigned long src, unsigned long length);
extern int flashread (unsigned long dst, unsigned long src, unsigned long length);

/*Cyrus Tsai*/
extern unsigned long file_length_to_server;
extern unsigned long file_length_to_client;
extern unsigned long image_address; 
/*this is the file length, should extern to flash driver*/
/*Cyrus Tsai*/

 
COMMAND_TABLE	MainCmdTable[] =
{
	{ "?"	  ,0, CmdHelp			, "HELP (?)				    : Print this help message"					},
	{ "HELP"  ,0, CmdHelp			, NULL																	},
	{ "D"	  ,2, CmdDumpWord		, "D <Address> <Len>"},
	{ "IPCONFIG"	  ,2, CmdIp			, "IPCONFIG:	<TargetAddress>"},
	//{ "EDL"	  ,2, CmdEDl			, "EDL:	FileName	<TargetAddress>"									},
	//{ "EUL"	  ,3, CmdEUl			, "EUL:	FileName	<SourceAddress>		<ByteCounts>"						},
	{ "J"  ,1, CmdCfn			, "J: Jump to <TargetAddress>"											},
	{ "FLW"   ,3, CmdFlw			, "FLW: FLW <dst><src><length>"					},
	{ "FLR"   ,3, CmdFlr			, "FLR: FLR <dst><src><length>"					},
};

static unsigned long	CurrentDumpAddress;
static unsigned long   sys_ipaddress;

/*
---------------------------------------------------------------------------
;				Monitor
---------------------------------------------------------------------------
*/
void monitor(void)
{
	char		buffer[ MAX_MONITOR_BUFFER +1 ];
	int		argc ;
	char**		argv ;
	int		i, retval ;
	i = &_end;
	i = (i & (~4095)) + 4096;
	//printf("Free Mem Start=%X\n", i);
	while(1)
	{
		printf( "%s", MAIN_PROMPT );
		memset( buffer, 0, MAX_MONITOR_BUFFER );
		GetLine( buffer, MAX_MONITOR_BUFFER,1);
		printf( "\n" );
		argc = GetArgc( (const char *)buffer );
		argv = GetArgv( (const char *)buffer );
		if( argc < 1 ) continue ;
		StrUpr( argv[0] );
		for( i=0 ; i < (sizeof(MainCmdTable) / sizeof(COMMAND_TABLE)) ; i++ )
		{
			if( ! strcmp( argv[0], MainCmdTable[i].cmd ) )
			{
#if 0
				if (MainCmdTable[i].n_arg != (argc - 1))
					printf("%s\n", MainCmdTable[i].msg);
				else
					retval = MainCmdTable[i].func( argc - 1 , argv+1 );
#endif
				retval = MainCmdTable[i].func( argc - 1 , argv+1 );
				break;
			}
		}
		if(i==sizeof(MainCmdTable) / sizeof(COMMAND_TABLE)) printf("Unknown command !\r\n");
	}
}

/*/
---------------------------------------------------------------------------
; Ethernet Download
---------------------------------------------------------------------------
*/




int CmdCfn(int argc, char* argv[])
{
	unsigned long		Address;
	void	(*jump)(void);
	if( argc > 0 )
	{
		if(!Hex2Val( argv[0], &Address ))
		{
			printf(" Invalid Address(HEX) value.\n");
			return FALSE ;
		}
	}

	printf("Jump to address=%X\n",Address);
	
	jump = (void *)(Address);
	jump();	
	
}
/* This command can be used to configure host ip and target ip	*/
extern char eth0_mac[6];
int CmdIp(int argc, char* argv[])
{
	unsigned char  *ptr;
	unsigned int i;
	int  ip[4];
	
	if (argc==0)
	{	
		printf(" Target Address=%d.%d.%d.%d\n",
		arptable_tftp[TFTP_SERVER].ipaddr.ip[0], arptable_tftp[TFTP_SERVER].ipaddr.ip[1], 
		arptable_tftp[TFTP_SERVER].ipaddr.ip[2], arptable_tftp[TFTP_SERVER].ipaddr.ip[3]);
		return;	 
	}			
	
	ptr = argv[0];

	for(i=0; i< 4; i++)
	{
		ip[i]=strtol((const char *)ptr,(char **)NULL, 10);		
		ptr = strchr(ptr, '.');
		ptr++;
	}
	arptable_tftp[TFTP_SERVER].ipaddr.ip[0]=ip[0];
	arptable_tftp[TFTP_SERVER].ipaddr.ip[1]=ip[1];
	arptable_tftp[TFTP_SERVER].ipaddr.ip[2]=ip[2];
	arptable_tftp[TFTP_SERVER].ipaddr.ip[3]=ip[3];
/*replace the MAC address middle 4 bytes.*/
	eth0_mac[1]=ip[0];
	eth0_mac[2]=ip[1];
	eth0_mac[3]=ip[2];
	eth0_mac[4]=ip[3];

	prom_printf("Now your Target IP is %d.%d.%d.%d\n", ip[0],ip[1],ip[2],ip[3]);
#if 0	
	ptr = argv[1];
	//prom_printf("You want to setup Host new ip as %s \n", ptr);	
	
	for(i=0; i< 4; i++)
	{
		ip[i]=strtol((const char *)ptr,(char **)NULL, 10);		
		ptr = strchr(ptr, '.');
		ptr++;
	}
	arptable[ARP_SERVER].ipaddr.ip[0]=ip[0];
	arptable[ARP_SERVER].ipaddr.ip[1]=ip[1];
	arptable[ARP_SERVER].ipaddr.ip[2]=ip[2];
	arptable[ARP_SERVER].ipaddr.ip[3]=ip[3];
	prom_printf("Now your Host IP is %d.%d.%d.%d\n", ip[0],ip[1],ip[2],ip[3]);
#endif	
		
}

/*int CmdEDl( int argc, char* argv[] )
{

	int			address;
	unsigned char 		iChar[2];
	int 	bytecount=0;
	
//	address = strtoul((const char*)(argv[1]), (char **)NULL, 16);	
//	prom_printf("Ethernet download %s to addr=%X\n? (Y/y/N/n)", argv[0], address);
	
		
//	GetLine( iChar, 2,1); 
//	if ((iChar[0] == 'Y') || (iChar[0] == 'y'))
//		printf("download! \n");
//	else
		printf("abort! \n");
	return TRUE;

}*/

/*int CmdEUl(int argc, char* argv[])
{

//	unsigned long		address;
//	unsigned long		bytecount;

//	unsigned char 		iChar[2];





//	address = strtoul((const char*)(argv[1]), (char **)NULL, 16);		
//	bytecount= strtoul((const char*)(argv[2]), (char **)NULL, 16);		

	
//	prom_printf("Ethernet upload %s from addr=%X with bytecount:%X\n? (Y/y/N/n)", 
//	argv[0], address,bytecount);	
	
//	GetLine( iChar, 2,1); 
//	if ((iChar[0] == 'Y') || (iChar[0] == 'y'))
//	        printf("\nUpload !\n");
//	else
	printf("abort! \n");
	
	
	return TRUE;
	
	
}*/


int CmdDumpWord( int argc, char* argv[] )
{
	
	unsigned long src;
	unsigned int len,i;
	
	src = strtoul((const char*)(argv[0]), (char **)NULL, 16);		
	len= strtoul((const char*)(argv[1]), (char **)NULL, 10);			
	while ( (src) & 0x03)
		src++;

	for(i=0; i< len ; i+=4,src+=16)
	{	
		printf("%X:	%X	%X	%X	%X\n",
		src, *(unsigned long *)(src), *(unsigned long *)(src+4), 
		*(unsigned long *)(src+8), *(unsigned long *)(src+12));
	}

	
	
}

/*
--------------------------------------------------------------------------
Flash Utility
--------------------------------------------------------------------------
*/


int CmdFlw(int argc, char* argv[])
{
	unsigned long dst,src;
	unsigned long length;

#define FLASH_WRITE_BYTE 4096

	dst = strtoul((const char*)(argv[0]), (char **)NULL, 16);		
	src = strtoul((const char*)(argv[1]), (char **)NULL, 16);		
	length= strtoul((const char*)(argv[2]), (char **)NULL, 16);		
//	length= (length + (FLASH_WRITE_BYTE - 1)) & FLASH_WRITE_BYTE;

/*Cyrus Tsai*/
/*file_length_to_server;*/
//length=file_length_to_server;
//length=length & (~0xffff)+0x10000;
/*Cyrus Tsai*/

	
	printf("Flash Program from %X to %X with %X bytes	?\n",src,dst,length);
	printf("(Y)es, (N)o->");
	if (YesOrNo())
		if (flashwrite(dst, src, length))
			printf("Flash Write Successed!\n");
		else
			printf("Flash Write Failed!\n");
	else
		printf("Abort!\n");
#undef FLASH_WRITE_BYTE	4096
				
}


int CmdFlr(int argc, char* argv[])
{
	int i;
	unsigned long dst,src;
	unsigned int length;
	//unsigned char TARGET;
//#define  FLASH_READ_BYTE	4096

	dst = strtoul((const char*)(argv[0]), (char **)NULL, 16);
	src = strtoul((const char*)(argv[1]), (char **)NULL, 16);
	length= strtoul((const char*)(argv[2]), (char **)NULL, 16);		
	//length= (length + (FLASH_READ_BYTE - 1)) & FLASH_READ_BYTE;

/*Cyrus Tsai*/
/*file_length_to_server;*/
//length=file_length_to_client;
//length=length & (~0xffff)+0x10000;
//dst=image_address;
file_length_to_client=length;
/*Cyrus Tsai*/

	printf("Flash read from %X to %X with %X bytes	?\n",src,dst,length);
	printf("(Y)es , (N)o ? --> ");

	if (YesOrNo())
	        //for(i=0;i<length;i++)
	        //   {
		//    if ( flashread(&TARGET, src+i,1) )
		//	printf("Flash Read Successed!, target %X\n",TARGET);
		//    else
		//	printf("Flash Read Failed!\n");
		//  }	
		    if (flashread(dst, src, length))
			printf("Flash Read Successed!\n");
		    else
			printf("Flash Read Failed!\n");
	else
		printf("Abort!\n");
//#undef	FLASH_READ_BYTE		4096

}


/*
------------------------------------------  ---------------------------------
; Command Help
---------------------------------------------------------------------------
*/
  

#if 0
extern int flash_test(void);
#endif

int CmdHelp( int argc, char* argv[] )
{
	int	i, LineCount ;

    printf("----------------- COMMAND MODE HELP ------------------\n");
	for( i=0, LineCount = 0 ; i < (sizeof(MainCmdTable) / sizeof(COMMAND_TABLE)) ; i++ )
	{
		if( MainCmdTable[i].msg )
		{
			LineCount++ ;
			printf( "%s\n", MainCmdTable[i].msg );
			if( LineCount == PAGE_ECHO_HEIGHT )
			{
				printf("[Hit any key]\r");
				WaitKey();
				printf("	     \r");
				LineCount = 0 ;
			}
		}
	}
	/*Cyrus Tsai*/
#if 0
 	/*Cyrus Tsai*/
    flash_test();   
#endif    
    
	return TRUE ;
}






int YesOrNo(void)
{
	unsigned char iChar[2];

	GetLine( iChar, 2,1);
	printf("\n");//vicadd
	if ((iChar[0] == 'Y') || (iChar[0] == 'y'))
		return 1;
	else
		return 0;
}
