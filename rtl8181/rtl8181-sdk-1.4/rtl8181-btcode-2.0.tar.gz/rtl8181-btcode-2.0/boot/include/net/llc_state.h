char *state_names[] = { 
	"ADM","CONN","RESET_WAIT","RESET_CHECK","SETUP",
	"RESET","D_CONN","ERROR","NORMAL"
};
