/* Separate to keep compilation of protocols.c simpler */
extern void atalk_proto_init(struct net_proto *pro);
