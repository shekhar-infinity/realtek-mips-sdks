
void boot_entry(void);

void boot_entry(void)
{


}
