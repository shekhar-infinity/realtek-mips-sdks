/*
 * This is included by init/main.c to check for architecture-dependent bugs.
 *
 * Needs:
 *	void check_bugs(void);
 */
#ifndef __ASM_BUGS_H
#define __ASM_BUGS_H

extern void check_bugs(void);

#endif /* __ASM_BUGS_H */
