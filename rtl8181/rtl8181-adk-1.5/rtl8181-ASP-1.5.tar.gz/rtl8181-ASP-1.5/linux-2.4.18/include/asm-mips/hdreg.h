/*
 *  Copyright (C) 1994-1996  Linus Torvalds & authors
 *  Copyright (C) 2001 Ralf Baechle
 */

/*
 *  This file contains the MIPS architecture specific IDE code.
 */

#ifndef _ASM_HDREG_H
#define _ASM_HDREG_H

typedef unsigned long ide_ioreg_t;

#endif /* _ASM_HDREG_H */
